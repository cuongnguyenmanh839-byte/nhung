import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'vn.atkdinhhoa.light', appName: 'ATK LIGHT', webDir: 'dist', android: { backgroundColor: '#220909' } };
export default config;
