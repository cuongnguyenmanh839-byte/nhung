import { useState } from 'react';
import { initialAreas, initialAlerts, modes } from '../data/mock';
import { lightingService } from '../services/lighting';
export function useLighting(){
 const [areas,setAreas]=useState(initialAreas),[brightness,setBrightness]=useState(70),[temperature,setTemperature]=useState(4000),[mode,setMode]=useState(0),[alerts,setAlerts]=useState(initialAlerts);
 const [displayName,changeDisplayName]=useState('Quản trị viên');
 const [schedules,setSchedules]=useState([{id:1,time:'18:00',mode:'Tham quan'},{id:2,time:'23:00',mode:'Tiết kiệm'}]);
 const on=areas.some(a=>a.on);
 const log=(title:string,detail:string)=>setAlerts(prev=>[{time:new Date().toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'}),title,detail},...prev].slice(0,30));
 const toggleSystem=()=>{const next=!on;void lightingService.setSystem(next);setAreas(prev=>prev.map(a=>({...a,on:next,lit:next?a.lamps:0})));log(next?'Đã bật toàn bộ hệ thống':'Đã tắt toàn bộ hệ thống','Thao tác từ trung tâm điều khiển');};
 const toggleArea=(id:string)=>{const area=areas.find(a=>a.id===id)!;void lightingService.setArea(id,!area.on);setAreas(prev=>prev.map(a=>a.id===id?{...a,on:!a.on,lit:a.on?0:a.lamps}:a));log(`Đã ${area.on?'tắt':'bật'} ${area.name}`,'Điều khiển khu vực');};
 const changeBrightness=(n:number)=>{setBrightness(n);void lightingService.setBrightness(n);};
 const changeTemperature=(n:number)=>{setTemperature(n);void lightingService.setTemperature(n);};
 const chooseMode=(n:number)=>{setMode(n);changeBrightness(modes[n].brightness);changeTemperature(modes[n].temp);log(`Chế độ ${modes[n].name}`,modes[n].detail);};
 return {areas,on,brightness,temperature,mode,alerts,displayName,changeDisplayName,schedules,setSchedules,toggleSystem,toggleArea,changeBrightness,changeTemperature,chooseMode,lit:areas.reduce((sum,a)=>sum+(a.on?a.lit:0),0)};
}
export type Lighting = ReturnType<typeof useLighting>;
