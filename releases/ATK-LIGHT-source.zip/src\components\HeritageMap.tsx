import { useState } from 'react';
import { Plus, Minus, LocateFixed, X } from 'lucide-react';
import type { Lighting } from '../hooks/useLighting';
import { Switch } from './Controls';
export function HeritageMap({state}:{state:Lighting}){
 const [zoom,setZoom]=useState(1),[selected,setSelected]=useState<string|null>(null);
 const area=state.areas.find(a=>a.id===selected);
 return <section className="panel heritage-map" aria-label="Bản đồ khu di tích"><div className={`map-scene ${state.on?'':'lights-off'}`} style={{transform:`scale(${zoom})`}}><img src="./reference.jpg" className="map-reference" alt="Bản đồ khu di tích ATK Định Hóa vào buổi tối với các tuyến đường chiếu sáng"/>{state.areas.map(a=><button key={a.id} className={`map-hotspot ${a.on?'':'off'}`} style={{left:`${a.x}%`,top:`${a.y}%`}} onClick={()=>setSelected(a.id)} aria-label={`Chọn ${a.name}`} title={`${a.name} · ${a.on?'Đang bật':'Đã tắt'}`}/>)}</div><h2>BẢN ĐỒ KHU DI TÍCH</h2><div className="map-zoom"><button aria-label="Phóng to bản đồ" onClick={()=>setZoom(z=>Math.min(1.8,z+.2))}><Plus/></button><button aria-label="Thu nhỏ bản đồ" onClick={()=>setZoom(z=>Math.max(1,z-.2))}><Minus/></button><button aria-label="Đặt lại bản đồ" onClick={()=>setZoom(1)}><LocateFixed/></button></div>{area&&<div className="map-popover"><button className="close" aria-label="Đóng khu vực" onClick={()=>setSelected(null)}><X/></button><strong>{area.name}</strong><span>{area.lamps} đèn · {area.on?'Đang bật':'Đã tắt'}</span><Switch on={area.on} onClick={()=>state.toggleArea(area.id)} label={`Bật/tắt ${area.name}`}/></div>}</section>;
}
