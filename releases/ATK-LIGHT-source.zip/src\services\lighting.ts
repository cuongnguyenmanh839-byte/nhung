import type { Area } from '../data/mock';
// Replace this adapter with REST requests; subscribe() can later use WebSocket/MQTT.
export interface LightingService { setArea(id: string, on: boolean): Promise<void>; setSystem(on: boolean): Promise<void>; setBrightness(value: number): Promise<void>; setTemperature(value: number): Promise<void>; subscribe(listener: (areas: Area[]) => void): () => void }
export const lightingService: LightingService = { async setArea(){}, async setSystem(){}, async setBrightness(){}, async setTemperature(){}, subscribe(){return ()=>{};} };
